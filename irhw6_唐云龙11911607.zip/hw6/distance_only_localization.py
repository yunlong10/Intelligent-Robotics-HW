"""

This script implements a multilateration algorithm that, given the coordinates of a finite number of radio stations,
and given their distances to the station (derived from the intensities of the signal they received in a previous step)
computes the most probable coordinates of the station. Even if the distances computed for each station do not match
(in terms of pointing to a single optimal solution) the algorithm finds the coordinates that minimize the error function
and returns the most optimal solution possible.


https://docs.scipy.org/doc/scipy/reference/generated/scipy.optimize.minimize.html
https://docs.scipy.org/doc/scipy/reference/optimize.minimize-neldermead.html#optimize-minimize-neldermead

"""

from scipy.optimize import minimize
from cmaes import CMA
import numpy as np
from trilateration import trilateration


def quadratic(x, c, r):
    loss=0
    for i in range(len(c)):
        loss+=(np.linalg.norm(c[i]-x)-r[i])**2

    return loss


if __name__ == "__main__":
    stations = list(np.array([[1, 1], [0, 1], [1, 0], [0, 0]]))
    distance_to_station = [0.1, 0.5, 0.5, 1.3]
    optimizer = CMA(mean=np.zeros(2), sigma=1.3)

    for generation in range(50):
        solutions=[]
        for _ in range(optimizer.population_size):
            x = optimizer.ask()
            # x=trilateration(distance_to_station,stations)
            loss=quadratic(x,stations,distance_to_station)
            solutions.append((x,loss))
            if _%6==0:
                print(f"#{generation} loss: {round(loss,6)} (x1={round(x[0],6)}, x2 = {round(x[1],6)})\n")
        optimizer.tell(solutions)

