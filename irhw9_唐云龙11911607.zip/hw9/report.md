# Homework 9

11911607 Yunlong Tang (唐云龙)

## Task 1

According to 

$K = \overline{P}_t H_t^T(H_t \overline{P}_t H_t^T + Q_t)^{-1}$

${X}_{Update} = X_{predict} + K*y$

$P_t =(I-K_tH_t)\overline{P}_t$

in line 57-59 of ekf_slam.py:

```python
K =PEst*H.T*np.linalg.pinv(S)
xEst =xEst+K*y
PEst =(np.eye(len(xEst))-K*H)*PEst
```
Output:
<div><img src=ekf_slam.png width=50%/>

## Task 2


predict->update->resmapling

in line 48-52 of pf_slam.py

```python
particles =predict_particles(particles,u)

particles =update_with_observation(particles,z)

particles =resampling(particles)
```
Outputs:
<div><img src=pf_slam1.png width=50%/>

<div><img src=pf_slam2.png width=50%/>
