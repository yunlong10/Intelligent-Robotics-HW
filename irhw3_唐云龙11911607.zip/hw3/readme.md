## Homework3

唐云龙 11911607

### Question 1

**Simulate the Astar algorithm depending on the given grid map. You can follow the Coding instruction to use the robotics simulator to complete this task.**

I fill the code of find_path() function in Astar.py according the hint. I implement the heuristic with L2 norm, then run the question1_run.py and draw the gifs. Following gif is the result.

<div> <img src=gif/astar.gif width=50%/>


### Question 2

**Simulate a robot to achieve the collision avoidance motion with dynamic window approach(DWA). You can follow the Coding instruction to use the robotics simulator to complete this task.**

I fill the code of dwa.py using L2 loss function to implement each cost and assign their weight by 10%, 30%, 40% and 20%. Then I run the question2_run.py and draw the gifs. Following gif is the result.

<div> <img src=gif/dwa.gif width=50%/>


### Question 3

**Combine the astar and dwa to achieve the 5D planning under the given grid map. You can follow the Coding instruction to use the robotics simulator to complete this task.**

I fill the code of astar_cost() in dwa.py by calculating the nearest distance between last point in predict trace and the trace given by A*. Then I run the question2_run.py and draw the gifs. Following gif is the result.

<div> <img src=gif/astar_dwa.gif width=50%/>

