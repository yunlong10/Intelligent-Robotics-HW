## Homework 6

11911607 唐云龙

### Range only based localization

#### Task 1

```python
def trilateration(distances_to_APs, STA_coordinates, target_position=None):
    x1,y1=STA_coordinates[0]
    x2,y2=STA_coordinates[1]
    x3,y3=STA_coordinates[2]
    d1,d2,d3=distances_to_APs
    A=np.array([[2*(x1-x3),2*(y1-y3)],[2*(x2-x3),2*(y2-y3)]])
    b=np.array([[x1**2-x3**2+y1**2-y3**2+d3**2-d1**2],
                [x2**2-x3**2+y2**2-y3**2+d3**2-d2**2]])
    target_position=np.linalg.pinv(A)@b
    return target_position.reshape(1,-1)[0]
```

**Output:**

[0.62 0.62]

#### Task 2-3

```python
def quadratic(x, c, r):
    loss=0
    for i in range(len(c)):
        loss+=(np.linalg.norm(c[i]-x)-r[i])**2
    return loss

if __name__ == "__main__":
    stations = list(np.array([[1, 1], [0, 1], [1, 0], [0, 0]]))
    distance_to_station = [0.1, 0.5, 0.5, 1.3]
    optimizer = CMA(mean=np.zeros(2), sigma=1.3)

    for generation in range(50):
        solutions=[]
        for _ in range(optimizer.population_size):
            x = optimizer.ask()
            # x=trilateration(distance_to_station,stations)
            loss=quadratic(x,stations,distance_to_station)
            solutions.append((x,loss))
            if _%6==0:
                print(f"#{generation} loss: {round(loss,6)} (x1={round(x[0],6)}, x2 = {round(x[1],6)})\n")
        optimizer.tell(solutions)
```

**Output:**

#0 loss: 6.803422 (x1=-0.284344, x2 = -0.692694)

#1 loss: 21.299297 (x1=2.518703, x2 = -1.397059)

#2 loss: 1.272416 (x1=1.362844, x2 = 0.453141)  

#3 loss: 3.565038 (x1=1.590654, x2 = 1.441193)  

#4 loss: 0.536483 (x1=1.074037, x2 = 0.932449)  

#5 loss: 2.572129 (x1=1.705453, x2 = 0.834242)  

#6 loss: 0.73808 (x1=0.492452, x2 = 1.135491)   

#7 loss: 1.674343 (x1=1.157255, x2 = 1.385778)  

#8 loss: 1.071476 (x1=0.797782, x2 = 0.245402)  

#9 loss: 0.393168 (x1=0.82005, x2 = 1.017173)   

#10 loss: 0.325466 (x1=0.949486, x2 = 0.778221) 

#11 loss: 0.374159 (x1=0.920751, x2 = 0.627569) 

#12 loss: 0.462597 (x1=0.91428, x2 = 0.54428)   

#13 loss: 0.286412 (x1=0.831002, x2 = 0.732165) 

#14 loss: 0.294216 (x1=0.726044, x2 = 0.865335) 

#15 loss: 0.39211 (x1=0.624503, x2 = 0.949642)  

#16 loss: 0.316061 (x1=0.856878, x2 = 0.678612)

#17 loss: 0.298842 (x1=0.722381, x2 = 0.758181)

#18 loss: 0.311505 (x1=0.816541, x2 = 0.923158)

#19 loss: 0.286176 (x1=0.758077, x2 = 0.868272)

#20 loss: 0.30191 (x1=0.719393, x2 = 0.883193)

#21 loss: 0.280406 (x1=0.753247, x2 = 0.790735)

#22 loss: 0.27303 (x1=0.814218, x2 = 0.792724)

#23 loss: 0.272679 (x1=0.805589, x2 = 0.811082)

#24 loss: 0.272949 (x1=0.79446, x2 = 0.797158)

#25 loss: 0.273129 (x1=0.812952, x2 = 0.814544)

#26 loss: 0.273164 (x1=0.805679, x2 = 0.788238)

#27 loss: 0.272605 (x1=0.809372, x2 = 0.803978)

#28 loss: 0.272538 (x1=0.805936, x2 = 0.802922)

#29 loss: 0.272609 (x1=0.801771, x2 = 0.799244)

#30 loss: 0.272555 (x1=0.802249, x2 = 0.801485)

#31 loss: 0.272533 (x1=0.803042, x2 = 0.805217)

#32 loss: 0.272534 (x1=0.804593, x2 = 0.805299)

#33 loss: 0.272531 (x1=0.804109, x2 = 0.802732)

#34 loss: 0.272532 (x1=0.804036, x2 = 0.802656)

#35 loss: 0.27253 (x1=0.802845, x2 = 0.804215)

#36 loss: 0.272527 (x1=0.803788, x2 = 0.804068)

#37 loss: 0.272527 (x1=0.80375, x2 = 0.803996)

#38 loss: 0.27253 (x1=0.802994, x2 = 0.80447)

#39 loss: 0.272528 (x1=0.804161, x2 = 0.803654)

#40 loss: 0.272527 (x1=0.803789, x2 = 0.803912)

#41 loss: 0.272527 (x1=0.804017, x2 = 0.803839)

#42 loss: 0.272527 (x1=0.803927, x2 = 0.804037)

#43 loss: 0.272527 (x1=0.804047, x2 = 0.803993)

#44 loss: 0.272527 (x1=0.804097, x2 = 0.803916)

#45 loss: 0.272527 (x1=0.804031, x2 = 0.803948)

#46 loss: 0.272527 (x1=0.803983, x2 = 0.803965)

#47 loss: 0.272527 (x1=0.803975, x2 = 0.803965)

#48 loss: 0.272527 (x1=0.803942, x2 = 0.804017)

#49 loss: 0.272527 (x1=0.80395, x2 = 0.803966)

### Robot Motion Models

#### Task 1-2

```python
costheta=np.cos(currentPos[2][0].astype('float'))
sintheta=np.sin(currentPos[2][0].astype('float'))
A=np.array([[0.5*costheta,0.5*costheta],
            [0.5*sintheta,0.5*sintheta],
            [1/L,-1/L]],dtype='float')
```


| square_left | square_right | backward |
| :----:  | :----:        | :----:     | 
| <div align=center> <img src=square_left.png width=80%/> </div> | <div align=center> <img src=square_right.png width=80%/> </div> | <div align=center> <img src=backward.png width=80%/> </div>  |

| forward | left_full_turn | right_full_turn |
| :----:  | :----:        | :----:     | 
| <div align=center> <img src=forward.png width=80%/> </div> | <div align=center> <img src=left_full_turn.png width=80%/> </div> | <div align=center> <img src=right_full_turn.png width=80%/> </div>  |



#### Task 3-4


| velocity  | encoder |
|  :----:   | :----:     |
| <div align=center> <img src=comparison_velocity.png width=50%/> </div> | <div align=center> <img src=comparison_encoder.png width=50%/> </div> |


#### Extra credit

According to the formulars of ICC-based differential drive model:

```python

def ICC_based_differential(currentPos, velL, velR, deltaT, noise = False, control_std = [0.01, 0.01]):
    L = 330.0
    w=(velR-velL)/L+np.random.normal(0.0,1.0)
    v=(velR+velL)/2+np.random.normal(0.0,1.0)
    theta=currentPos[2,0].astype('float')
    costheta=np.cos(theta)
    sintheta=np.sin(theta)
    costheta_wt=np.cos(theta+w*deltaT)
    sintheta_wt=np.sin(theta+w*deltaT)
    deltaPos = np.array([
                        [-(v/w)*sintheta+(v/w)*sintheta_wt],
                        [(v/w)*costheta-(v/w)*costheta_wt],
                        [w*deltaT]])
    currentPos = currentPos + deltaPos
    return currentPos
```

<div> <img src=icc.png width=50%/>
