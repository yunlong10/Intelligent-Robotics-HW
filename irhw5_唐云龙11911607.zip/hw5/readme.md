## Homework 5

11911607 唐云龙

#### Question 1

Using $G\leftarrow \gamma G+R_{t+1}$ to get $Returns(S_t,A_t)$, and update the average values of $Q(S_t,A_t)\leftarrow average(Returns(S_t,A_t))$.

<div> <img src=gif/monte_carlo_es.gif width=50%/>

#### Question 2

I filled the key part with $Q(S,A)\leftarrow Q(S,A)+\alpha[R+\gamma Q(S',A')-Q(S,A)]$

<div> <img src=gif/SARSA.gif width=50%/>

#### Question 3

I filled the key part with $Q(S,A)\leftarrow Q(S,A)+\alpha[R+\gamma max_aQ(S',a)-Q(S,A)]$

<div> <img src=gif/Q_learning.gif width=50%/>

#### Question 4

I add a heuristic reward using **distance to goal** & **cost from source reward**.

```
reward+=self.heuristic_reward(next_x,next_y,C1,C2)
...

def heuristic_reward(self,x,y,C1,C2):
    '''distance to goal & cost from source reward'''
    return -C1*(abs(x-16)+abs(y-16))-C2*(abs(x-2)+abs(y-2))
```

When C1=C2=0.006, the performances in the three questions are all good enough.
