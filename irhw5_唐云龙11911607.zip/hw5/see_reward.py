import numpy as np
from grid_map import grid_map
from ir_sim.env import env_base
from pathlib import Path
from reinforcement_learning import reinforcement_learning
import sys
from pathlib import Path
np.random.seed(0)
animation = True

# path set
cur_path = sys.path[0]
map_path = cur_path + '/map_matrix.npy'
reward_path = cur_path + '/reward_matrix.npy'
image_path = Path(__file__).parent / 'image' 
gif_path = Path(__file__).parent / 'gif'

# load map and reward matrix
map_matrix = np.load(map_path)
reward_matrix = np.load(reward_path)
print(reward_matrix)
print(map_matrix.shape)
print(map_matrix[16,16])