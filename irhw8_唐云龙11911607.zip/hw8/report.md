# Homework 8

11911607 Yunlong Tang (唐云龙)

### Task 1

According to the given conditions, we have 

$p = \frac{exp \, l}{1+exp \, l} = \frac{exp \, l + 1 -1}{1+exp \,l} = 1 - \frac{1}{1+exp \, l}$

Therefore, the implementation is:

```python        
p_m = 1-1/(1+np.exp(l_m))
```

Result:

<div><img src=task1.png width=50%/>

### Task 2

With the similar way, the log-odds update formula can be recursively unwarpped by:

$l(m_i|z_{1:t},~;x_{1:t})~;=~;l(m_i|z_t,~;x_t)~;+;~;l(m_i|z_{1:t-1},~;x_{1:t-1})~;-~;l(m_i)~;\\=~;~;l(m_i|z_t,~;x_t)~;+;~;l(m_i|z_{1:t-1},~;x_{1:t-1})~;+;~;l(m_i|z_{1:t-2},~;x_{1:t-2})~;-~;2.l(m_i)~;\\=~;...~;=~;~;\sum_{k=1}^{t}l(m_i|z_k,x_k)~;-~;t.l(m_i)"  l(m_i|z_{1:t}, x_{1:t}) = l(m_i|z_t, x_t) + l(m_i|z_{1:t-1}, x_{1:t-1}) - l(m_i) \\= l(m_i|z_t, x_t) + l(m_i|z_{1:t-1}, x_{1:t-1}) + l(m_i|z_{1:t-2}, x_{1:t-2}) - 2.l(m_i) \\= ... = \sum_{k=1}^{t}l(m_i|z_k,x_k) - t.l(m_i)$

And every grid cell with a distance  smaller than the measured distance is assumed to be occupied with p = 0.3. Every cell behind the measured distance is occupied with p = 0.6.

Therefore, the implementation is:

```python
for z in measurements:
    i = z//10 
    if i+3<=len(l_m):
        l_m[0:i+1]+=np.log(0.3/0.7) 
        l_m[i+1:i+3]+=np.log(0.6/0.4)
    elif i+1<=len(l_m):
        l_m[0:i+1]+=np.log(0.3/0.7) 
        l_m[i+1:]+=np.log(0.6/0.4)
    else:
        l_m+=np.log(0.3/0.7) 

p_m = 1-1/(1+np.exp(l_m))
```


Result:

<div><img src=task2.png width=50%/>

The result is totally the same with that in task 1, which proves that in the occupancy grid mapping framework the occupancy value of a grid cell $P(m_j|x_{1:t};z_{1:t})$ is independent of the order in which the measurements are integrated.