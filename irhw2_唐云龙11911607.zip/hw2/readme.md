## Homework2

唐云龙 11911607

### Question 1

**(a)Imagine you want your robot to perform navigation tasks, which approach would you choose?**

I may behavior based approaches because it has high robustness and needs no model advance.

**(b)What are the benefits of the behavior based paradigm?**

- With high robustness.
- Multiple behaviors can be emergent.
- No model. There is no need for a global model in advance.
- support good software design principles due to modularity.

**(c)Which approaches will win in the long run?**

I think hybrid approaches will win in the long run since it has the both advantages of classical (world model used for planning) and behavior base(closed loop, reactive control).

### Question 2

**(a)How to generate uniform, perpendicular, attractive, repulse, tangential forces for a robot and obstacles with known positions? Provide related mathematical formulas.**

uniform: $\vec{v}=\vec{v}_0$

perpendicular: $\vec{v}=\eta\vec{h}\frac{v_p}{h^3}$

attractive: $\vec{v}=\xi(\vec{r_0}-\vec{r})|\vec{r}-\vec{r_0}|v_0$

repulse: $\vec{v}=\eta(\vec{r}-\vec{r_0})\frac{v_0}{|\vec{r}-\vec{r_0}|^3}$

tangential: $\vec{v}=\vec{\omega_0}\times(\vec{r}-\vec{r_0})$

(b)**Please simulate the motions of a robot with the given force fields from the following figure.**

I fill the code of potential_field.py according to above formulas for each kind of field, then run the question2_run.py and draw the gifs. Following gifs are uniform, perpendicular, attractive, repulse and tangential, repectively.

| Uniform | Perpendicular | Attractive |
| :----:  | :----:        | :----:     | 
| <div align=center> <img src=gif/uniform.gif width=80%/> </div> | <div align=center> <img src=gif/perpendicular.gif width=80%/> </div> | <div align=center> <img src=gif/attractive.gif width=80%/> </div>  |

| Repulsive  | Tangential |
|  :----:   | :----:     |
| <div align=center> <img src=gif/repulsive.gif width=50%/> </div> | <div align=center> <img src=gif/tangential.gif width=50%/> </div> |

### Question 3
**Simulate a robot can reach the goal without sticking into a local trap. Provide codes and plots of simulation results.Simulate a robot can reach the goal without sticking into a local trap. Provide codes and plots of simulation results.**

I fill the code of question3_run.py according to above formulas for each kind of field, then run the question3_run.py and draw the gif.

<div align=center> <img src=gif/potential_field.gif width=50%/>

