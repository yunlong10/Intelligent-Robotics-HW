## Homework 4

11911607 唐云龙

#### Question 1~3

I filled the code in `policy_iteration()` and `value_iteration()` of **mdp.py** according to the formula of the value iteration$$v(s)=\max_a\sum_{s'}p(s^{'}|s,a)[r(s,a,s^{'})+\gamma v(s^{'})],$$and the policy iteraton$$\pi(s)=argmax_a\sum_s^{'}p(s^{'}|s,a)[r(s,a,s^{'})+\gamma v(s^{'})]$$and yielded the result:

<div> <img src=gif/mdp.gif width=50%/>
