import numpy as np

class potential_fields:
    
    # Please complete these functions for question2, the arguments such as coefficient can be changed by your need. The return value should be a 2*1 matrix for robot to perform

    def uniform(self, vector=np.array([ [1], [0] ]), coefficient=1):
        # Please complete this function for question2
        return coefficient*vector

    def perpendicular(self, line_obstacle, car_position, coefficient=1):
        # line_obstacle: [px1, py1, px2, py2]
        # Please complete this function for question2
        px1, py1, px2, py2=line_obstacle
        v=np.array([[px1],[py1]])
        w=np.array([[px2],[py2]])
        h,proj_point,_=self.shortest_distance_point(v,w,car_position)
        vector=coefficient*(car_position-proj_point)/(h**3)

        return vector
    
    def attractive(self, goal_point, car_position, coefficient=1):
        # Please complete this function for question2
        l2=(goal_point-car_position).T@(goal_point-car_position)
        return coefficient*(goal_point-car_position)*np.sqrt(l2)

    def repulsive(self, obstacle_point, car_position, coefficient=1):
        # Please complete this function for question2
        l2=(obstacle_point-car_position).T@(obstacle_point-car_position)
        l=np.sqrt(l2)
        return coefficient*(car_position-obstacle_point)/(l**3)

    def tangential(self, point, car_position, coefficient=1):
        # Please complete this function for question2
        d=car_position-point
        d0,d1=d[0][0],d[1][0]
        r=coefficient*np.array([d0,d1,0])
        w=np.array([d0,d1,1])
        v=np.cross(w,r)
        return np.array([[v[0]],[v[1]]])

    def shortest_distance_point(self, v, w, p):
        # the minimum distance between line segment vw, and point p
        # v, w, p all are 2*1 matrix

        l2 = (w - v).T @ (w - v)
        if l2 == 0:
            return np.linalg.norm( p-v )

        t = max(0, min(1, (p - v).T @ (w - v) / l2 ))
        proj_point = v + t * (w-v)
        min_distance = np.linalg.norm( p-proj_point )
        
        return min_distance, proj_point, t

